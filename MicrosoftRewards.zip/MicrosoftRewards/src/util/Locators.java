package util;

public enum Locators {
	  XPATH("XPATH"),
	    ID("ID"),
	    NAME("NAME"),
	    CSS("CSS"),
	    TAGNAME("TAGNAME"),
	    LINKTEXT("LINKTEXT"),
	    DOM("DOM")
	    ;

	    public final String text;

	    /**
	     * @param text
	     */
	    private Locators(final String text) {
	        this.text = text;
	    }

	    /* (non-Javadoc)
	     * @see java.lang.Enum#toString()
	     */
	    @Override
	    public String toString() {
	        return text;
	    }
}
