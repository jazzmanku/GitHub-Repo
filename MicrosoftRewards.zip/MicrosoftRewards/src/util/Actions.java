package util;

public enum Actions {
	    SET("SET"),
	    CLEAR("CLEAR"),
	    DOUBLECLICK("DBLCLICK"),
	    CLICK("CLICK"),
	    MOVETO("MOVETO"),
	    HIGHLIGHTTEXT("HTEXT"),
	    ACTIONCLICK("ACCLICK")
	    ;

	    public final String text;

	    /**
	     * @param text
	     */
	    private Actions(final String text) {
	        this.text = text;
	    }

	    /* (non-Javadoc)
	     * @see java.lang.Enum#toString()
	     */
	    @Override
	    public String toString() {
	        return text;
	    }
}

