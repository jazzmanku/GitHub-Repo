package util;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Utilities {
	WebElement e=null;
	Actions ac = null;
		
	public void SwitchWindows(WebDriver d, int childNode) {
		Set<String> ids = d.getWindowHandles();
		Iterator<String> i = ids.iterator();
		String parentID = i.next();
		String firstChildID = i.next();
		if(childNode==1)
			d.switchTo().window(firstChildID);
		if(childNode==0)
			d.switchTo().window(parentID);
		System.out.println( d.getTitle());
		
	}
	
	public void setLocator(WebDriver d, Locators l, String locExpression) {
		switch (l.text) {
		case "XPATH":
			e = d.findElement(By.xpath(locExpression));
			break;
		case "ID":
			e = d.findElement(By.id(locExpression));
			break;
		case "NAME":
			e = d.findElement(By.name(locExpression));
			break;
		case "TAGNAME":
			e = d.findElement(By.tagName(locExpression));
			break;
		case "LINKTEXT":
			e = d.findElement(By.linkText(locExpression));
			break;
		case "CSS":
			e = d.findElement(By.cssSelector(locExpression));
			break;
		default:
			e = d.findElement(By.xpath(""));
			break;
		}
	}
	
	/**
	 * 
	 * @param d : WebDriver instance
	 * @param l : The Locator functionality specified to locate the Web Element on the page e.g. XPATH, ID, NAME etc.
	 * @param locExpression  : The unique identifier to pin point the Web Element.
	 * @param action : Action needs to be done, type in text box field or click on the element
	 * @param value : Value is optional field, it is only used when Action is "SET".
	 */
	@SuppressWarnings("null")
	public void setElement(WebDriver d, Locators l, String locExpression, util.Actions action, String... value) {
		setLocator(d, l, locExpression);
		
		switch (action.text) {
		case "SET":
			e.sendKeys(value[0].toString());
			break;
		case "CLICK":
			e.click();
			break;
		case "CLEAR":
			e.clear();
			break;
		case "DBLCLICK":
			ac.doubleClick(e).build().perform();
			break;
		case "MOVETO":
			ac.moveToElement(e).build().perform();
			break;
		case "HTEXT":
			ac.doubleClick(e).build().perform();
			break;
		case "ACCLICK":
			ac.click(e).build().perform();
			break;
		
		default:
			break;
		}
	}

	
	public static void foo(String a, Integer... b) {
	    Integer b1 = b.length > 0 ? b[0] : 0;
	    Integer b2 = b.length > 1 ? b[1] : 0;
	    //...
	    System.out.println(b1 + " , "+ b2);
	}
	
	public static void main(String[] args) {
		foo("a");
		foo("a", 1, 2);
	}
}


