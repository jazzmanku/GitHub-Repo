import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import util.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class RewardsAutomation {
	WebDriver d = null;
	Utilities u = new Utilities();
	String loginURL = "https://login.live.com/";
	String rewardsURL ="https://account.microsoft.com/rewards";
	String bingURL ="http://www.bing.com/";
	String hoTTrendsURL ="https://trends.google.com/trends/hottrends";
	String username = "manku.jas@outlook.com";
	String password = "mrjatt123";
	
	String emailXpath = "//*[@name='loginfmt']";
	String pwdXpath = "//*[@name='passwd']";
	String nextBtnXpath = "//*[@value='Next']";  /* value = 'Next' */
	String signInBtn = "//*[@value='Sign in']";
	String keepMeSignedChkBox = "//*[@id=\"idChkBx_PWD_KMSI0Pwd\"]"; /*name='KMSI' */
	
	String searchXpath = "//*[@id='sb_form_q']";
	String searchBtnXpath = "//*[@id='sb_form_go']";
	String hotTrendsXpath = ".//*[@class=\"hottrends-single-trend-title ellipsis-maker-inner\"]";
	List<String> trendList = new ArrayList<String>();
	String score =null;
	
	//@Parameters("BrowserCode")
	@BeforeTest
	  public void beforeTest(/*String BrowserCode*/) {
		String BrowserCode = "FF";
		switch (BrowserCode) {
		  case "FF":
			  	d = new FirefoxDriver();
				break;
		  case "CH":
			  	d = new ChromeDriver();
				break;

		default:
			d = new FirefoxDriver();
			break;
		}
		   
	  }
	
	@Test(enabled=true,priority=0)
	public void login() {
		
		try {
			d.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			d.get(loginURL);
			u.setElement(d, Locators.XPATH, emailXpath, Actions.SET,username);
			u.setElement(d, Locators.XPATH, nextBtnXpath, Actions.CLICK);
			Thread.sleep(1000);
			u.setElement(d, Locators.XPATH, pwdXpath, Actions.SET,password);
			Thread.sleep(1000);
			u.setElement(d, Locators.XPATH, keepMeSignedChkBox, Actions.CLICK);
			Thread.sleep(1000);
			u.setElement(d, Locators.XPATH, signInBtn, Actions.CLICK);

			System.out.println("Sign in succesful");
		}
		catch(Exception e) {
			System.out.println("The Exception Message : " + e.getMessage());
		}
	}
	
	@Test(enabled=false, priority=1, dependsOnMethods= {"login"})
	public void collectRewards() throws InterruptedException {
		d.get(rewardsURL);
		Thread.sleep(2000);
		System.out.println("On Current Page: " + d.getTitle());	
	}
	
	@Test(enabled=true, priority=3, dependsOnMethods= {"getHotTrends"})
	public void doSearches() throws InterruptedException {
		String newScore=null;
		d.get(bingURL);
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(d, 10);
		WebElement elemScore = wait.until(ExpectedConditions.elementToBeClickable(By.id("id_rc")));
		score = d.findElement(By.xpath("//span[@id='id_rc']")).getAttribute("innerHTML");
		System.out.println("Current Points by innerhtml-1 attribute : " + score);
		d.navigate().refresh();
		Thread.sleep(2000);
		for (String s : trendList) {
			System.out.println("Searching : "+ s);
		}
		//score = elemScore.getAttribute("innerHTML");
		//System.out.println("Current Points by innerhtml attribute : " + score);
		//score = elemScore.getText();
		//System.out.println("Current Points by text : " + score);
		for (String s : trendList) {
			Thread.sleep(2000);
			u.setElement(d, Locators.XPATH, searchXpath, Actions.SET,s);
			u.setElement(d, Locators.XPATH, searchBtnXpath, Actions.CLICK);
			u.setElement(d, Locators.XPATH, searchXpath, Actions.CLEAR);
			newScore = d.findElement(By.xpath("//span[@id='id_rc']")).getAttribute("innerHTML");
			System.out.println("New Points : " + newScore);
			if(newScore.equals(score)) break;
		}
		System.out.println("Page title is : "+d.getTitle());
	}
	
	@Test(enabled=true, priority=2)
	public void getHotTrends() {
		d.get(hoTTrendsURL);
		
		Iterator<WebElement> it =  d.findElements(By.xpath(hotTrendsXpath)).iterator();
		while(it.hasNext()){
			trendList.add(it.next().getText());
		}
		
	}
	@AfterTest
	public void afterTest() throws InterruptedException {
		System.out.println("In the final block, stopping the execution");
		Thread.sleep(3000);
		d.quit();
	}
}
